# Virtual Joystick GPS V2 — diagnostic build

This Android project provides a floating joystick UI and a mock-location test provider for developer/testing use on a device you own or are authorized to test.

## Setup
1. Install the debug APK.
2. Grant location permission and Display over other apps permission.
3. In Developer options, select Virtual Joystick GPS V2 as the mock location app.
4. Start the floating joystick. The panel shows `Mock GPS: READY` when provider setup and updates succeed; otherwise it displays an error for troubleshooting.
5. Keep Android Location enabled. Some apps may ignore or detect mock locations and may not automatically recenter the map; use the map's current-location button to check the blue dot.

## Notes
- This is a debug build, not a Play Store release.
- Mock location can be detected or ignored by apps.
- Do not use simulated location to misrepresent your location to services or people.
