# Virtual Joystick GPS V2 — current-location base and editable coordinates

This Android debug project is intended for location testing on a device you own or are authorized to test.

## New controls
- **USE MY CURRENT LOCATION** stops the mock provider temporarily, requests a fresh device location, and fills the latitude/longitude fields.
- Latitude and longitude can be edited manually.
- **START / UPDATE FLOATING JOYSTICK** starts the overlay at the chosen coordinates or updates an already-running overlay to those coordinates.
- The overlay's **RESET** button returns to the last coordinates selected in the main app, rather than a fixed Manila point.
- Moving the joystick changes the simulated coordinates; the status text reports mock-provider errors.

## Setup
1. Install the debug APK.
2. Grant location permission and Display over other apps permission.
3. In Developer options, choose this app under Select mock location app.
4. Tap USE MY CURRENT LOCATION, or type latitude/longitude yourself.
5. Tap START / UPDATE FLOATING JOYSTICK.
6. Check the overlay status. If it reports an error, inspect that error before assuming GPS simulation is active.

## Notes
- This is a debug build, not a Play Store release.
- The app requests the device's last/fresh available location; accuracy depends on Android Location being enabled and GPS/network reception.
- Some apps may detect or ignore mock locations and may not automatically recenter the map; use the map's current-location button to check the blue dot.
- Do not use simulated location to misrepresent your location to services or people.
