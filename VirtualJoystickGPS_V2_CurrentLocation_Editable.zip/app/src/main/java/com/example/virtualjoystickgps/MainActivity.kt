package com.example.virtualjoystickgps

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var latitudeInput: EditText
    private lateinit var longitudeInput: EditText
    private val handler = Handler(Looper.getMainLooper())
    private var locationListener: LocationListener? = null
    private var locationTimeout: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        val title = TextView(this).apply {
            text = "Virtual Joystick GPS V2"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(0xFF14213D.toInt())
        }
        val description = TextView(this).apply {
            text = "Use your current device location as the starting point, or enter coordinates manually. Move the floating joystick to simulate movement."
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 16)
        }
        val latLabel = TextView(this).apply { text = "Latitude (-90 to 90)"; textSize = 14f }
        latitudeInput = EditText(this).apply {
            hint = "e.g. 14.599500"
            singleLine = true
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextSize(16f)
        }
        val lonLabel = TextView(this).apply { text = "Longitude (-180 to 180)"; textSize = 14f }
        longitudeInput = EditText(this).apply {
            hint = "e.g. 120.984200"
            singleLine = true
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextSize(16f)
        }
        val current = Button(this).apply {
            text = "USE MY CURRENT LOCATION"
            setOnClickListener { useCurrentLocation() }
        }
        val overlayPermission = Button(this).apply {
            text = "1. ALLOW FLOATING OVERLAY"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Overlay permission already granted.", Toast.LENGTH_SHORT).show()
            }
        }
        val locationPermission = Button(this).apply {
            text = "2. GRANT LOCATION PERMISSION"
            setOnClickListener {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)
                } else Toast.makeText(this@MainActivity, "Location permission already granted.", Toast.LENGTH_SHORT).show()
            }
        }
        val start = Button(this).apply {
            text = "START / UPDATE FLOATING JOYSTICK"
            setOnClickListener { startOrUpdateJoystick() }
        }
        val stop = Button(this).apply {
            text = "STOP FLOATING JOYSTICK"
            setOnClickListener {
                stopLocationRequest()
                stopService(Intent(this@MainActivity, JoystickOverlayService::class.java))
                Toast.makeText(this@MainActivity, "Floating joystick stopped.", Toast.LENGTH_SHORT).show()
            }
        }
        val note = TextView(this).apply {
            text = "Tip: tap USE MY CURRENT LOCATION first. You can edit latitude/longitude manually, then tap START / UPDATE. To get a fresh real GPS fix, the app briefly stops the mock joystick service."
            textSize = 12f
            setTextColor(0xFF46546A.toInt())
            setPadding(4, 12, 4, 8)
        }

        listOf(title, description, latLabel, latitudeInput, lonLabel, longitudeInput, current,
            overlayPermission, locationPermission, start, stop, note).forEach { view ->
            root.addView(view, LinearLayout.LayoutParams(-1, if (view is EditText) -2 else -2).apply { bottomMargin = 8 })
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        prefillLastKnownLocation()
    }

    private fun prefillLastKnownLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val candidates = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                .mapNotNull { provider -> try { lm.getLastKnownLocation(provider) } catch (_: Exception) { null } }
            val best = candidates.maxByOrNull { it.time }
            if (best != null && latitudeInput.text.isNullOrBlank() && longitudeInput.text.isNullOrBlank()) {
                setCoordinates(best)
            }
        } catch (_: Exception) { }
    }

    private fun useCurrentLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)
            Toast.makeText(this, "Grant location permission, then tap this button again.", Toast.LENGTH_LONG).show()
            return
        }

        // Stop our test provider before asking Android for a real device location.
        stopService(Intent(this, JoystickOverlayService::class.java))
        Toast.makeText(this, "Getting your device location… keep Location enabled.", Toast.LENGTH_LONG).show()
        handler.postDelayed({ requestFreshLocation() }, 600L)
    }

    private fun requestFreshLocation() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { provider -> try { lm.isProviderEnabled(provider) } catch (_: Exception) { false } }
        if (providers.isEmpty()) {
            Toast.makeText(this, "Turn on Location/GPS and try again, or enter coordinates manually.", Toast.LENGTH_LONG).show()
            return
        }
        stopLocationRequest()
        var finished = false
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (finished) return
                finished = true
                setCoordinates(location)
                stopLocationRequest()
                Toast.makeText(this@MainActivity, "Current location loaded.", Toast.LENGTH_SHORT).show()
            }
            @Deprecated("Deprecated by Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        locationListener = listener
        try {
            for (provider in providers) {
                try { lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper()) } catch (_: SecurityException) { }
            }
        } catch (e: Exception) {
            stopLocationRequest()
            Toast.makeText(this, "Could not get location: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        val timeout = Runnable {
            if (!finished) {
                finished = true
                val last = providers.mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: Exception) { null } }
                    .maxByOrNull { it.time }
                stopLocationRequest()
                if (last != null) {
                    setCoordinates(last)
                    Toast.makeText(this, "Using last known device location. For better accuracy, try outdoors.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "No location fix yet. Keep GPS enabled or enter coordinates manually.", Toast.LENGTH_LONG).show()
                }
            }
        }
        locationTimeout = timeout
        handler.postDelayed(timeout, 12000L)
    }

    private fun stopLocationRequest() {
        locationTimeout?.let { handler.removeCallbacks(it) }
        locationTimeout = null
        val listener = locationListener
        if (listener != null) {
            try { (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(listener) } catch (_: Exception) { }
        }
        locationListener = null
    }

    private fun setCoordinates(location: Location) {
        latitudeInput.setText("%.6f".format(java.util.Locale.US, location.latitude))
        longitudeInput.setText("%.6f".format(java.util.Locale.US, location.longitude))
    }

    private fun startOrUpdateJoystick() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)
            Toast.makeText(this, "Grant location permission first.", Toast.LENGTH_LONG).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow floating overlay first.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val latitude = latitudeInput.text.toString().trim().toDoubleOrNull()
        val longitude = longitudeInput.text.toString().trim().toDoubleOrNull()
        if (latitude == null || longitude == null || latitude !in -90.0..90.0 || longitude !in -180.0..180.0) {
            Toast.makeText(this, "Enter valid latitude and longitude, or tap USE MY CURRENT LOCATION.", Toast.LENGTH_LONG).show()
            return
        }
        val serviceIntent = Intent(this, JoystickOverlayService::class.java).apply {
            action = JoystickOverlayService.ACTION_START
            putExtra(JoystickOverlayService.EXTRA_LATITUDE, latitude)
            putExtra(JoystickOverlayService.EXTRA_LONGITUDE, longitude)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
            Toast.makeText(this, "Joystick started/updated at %.6f, %.6f".format(java.util.Locale.US, latitude, longitude), Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start joystick: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        stopLocationRequest()
        super.onDestroy()
    }
}
