plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.virtualjoystickgps"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.virtualjoystickgps"
        minSdk = 26
        targetSdk = 32
        versionCode = 2
        versionName = "2.0"
    }
}
