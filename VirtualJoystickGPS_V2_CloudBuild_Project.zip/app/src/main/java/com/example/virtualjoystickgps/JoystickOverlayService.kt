package com.example.virtualjoystickgps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class JoystickOverlayService : Service() {
    companion object {
        const val ACTION_START = "com.example.virtualjoystickgps.START"
        private const val CHANNEL_ID = "gps_joystick_channel"
    }

    private lateinit var wm: WindowManager
    private lateinit var locationManager: LocationManager
    private var panel: LinearLayout? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var running = false
    private var lat = 14.5995
    private var lon = 120.9842
    private var speedMps = 4.0
    private var dx = 0f
    private var dy = 0f
    private var lastTick = 0L
    private var coords: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val now = SystemClock.elapsedRealtime()
            if (lastTick > 0) {
                val dt = ((now - lastTick).coerceAtMost(500L)) / 1000.0
                val mag = sqrt((dx * dx + dy * dy).toDouble()).coerceAtMost(1.0)
                if (mag > 0.05) {
                    val north = (-dy / mag) * speedMps * dt
                    val east = (dx / mag) * speedMps * dt
                    lat += north / 111320.0
                    lon += east / (111320.0 * cos(Math.toRadians(lat)).coerceAtLeast(0.01))
                    if (lon > 180) lon -= 360.0
                    if (lon < -180) lon += 360.0
                }
                publishLocation()
                updateCoords()
            }
            lastTick = now
            handler.postDelayed(this, 250L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(20, buildNotification())
        if (panel == null) createOverlay()
        setupMockProviders()
        running = true
        lastTick = 0L
        handler.removeCallbacks(loop)
        handler.post(loop)
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Virtual GPS joystick", NotificationManager.IMPORTANCE_LOW))
        }
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Virtual Joystick GPS")
                .setContentText("Mock GPS simulation is running")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Virtual Joystick GPS")
                .setContentText("Mock GPS simulation is running")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build()
        }
    }

    private fun createOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 12)
            setBackgroundColor(0xEEFFFFFF.toInt())
        }
        val header = TextView(this).apply {
            text = "☰  GPS Joystick  •  tap and drag this bar"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xFF14213D.toInt())
            setOnTouchListener(object : View.OnTouchListener {
                var startX = 0
                var startY = 0
                var touchX = 0f
                var touchY = 0f
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    val p = overlayParams ?: return false
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            startX = p.x; startY = p.y
                            touchX = event.rawX; touchY = event.rawY
                            return true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            p.x = startX + (event.rawX - touchX).toInt()
                            p.y = startY + (event.rawY - touchY).toInt()
                            try { wm.updateViewLayout(root, p) } catch (_: Exception) {}
                            return true
                        }
                    }
                    return false
                }
            })
        }
        coords = TextView(this).apply {
            textSize = 11f
            setTextColor(0xFF243047.toInt())
            setPadding(8, 8, 8, 8)
        }
        val joystick = FloatingJoystick(this) { x, y -> dx = x; dy = y }
        val speedLabel = TextView(this).apply {
            text = "Speed: 4 m/s"
            textSize = 12f
            setTextColor(0xFF243047.toInt())
        }
        val speedBar = SeekBar(this).apply {
            max = 19
            progress = 3
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    speedMps = (progress + 1).toDouble()
                    speedLabel.text = "Speed: ${speedMps.toInt()} m/s"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val reset = TextView(this).apply {
            text = "RESET"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(16, 12, 16, 12)
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF2457D6.toInt())
            setOnClickListener { lat = 14.5995; lon = 120.9842; publishLocation(); updateCoords() }
        }
        val close = TextView(this).apply {
            text = "CLOSE"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(16, 12, 16, 12)
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFFB42318.toInt())
            setOnClickListener { stopSelf() }
        }
        buttons.addView(reset, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(close, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)
        root.addView(coords)
        root.addView(joystick, LinearLayout.LayoutParams(280, 250))
        root.addView(speedLabel)
        root.addView(speedBar)
        root.addView(buttons)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 160
        }
        wm.addView(root, overlayParams)
        panel = root
        updateCoords()
    }

    private fun setupMockProviders() {
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        for (provider in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try {
                locationManager.addTestProvider(
                    provider, false, false, false, false,
                    true, true, true, Criteria.POWER_LOW, Criteria.ACCURACY_FINE
                )
                locationManager.setTestProviderEnabled(provider, true)
            } catch (_: Exception) {}
        }
        publishLocation()
    }

    private fun publishLocation() {
        if (!::locationManager.isInitialized) return
        val now = SystemClock.elapsedRealtimeNanos()
        val loc = Location(LocationManager.GPS_PROVIDER).apply {
            latitude = this@JoystickOverlayService.lat
            longitude = this@JoystickOverlayService.lon
            altitude = 10.0
            accuracy = 3f
            speed = speedMps.toFloat()
            bearing = ((Math.toDegrees(atan2(dx.toDouble(), -dy.toDouble())) + 360.0) % 360.0).toFloat()
            time = System.currentTimeMillis()
            elapsedRealtimeNanos = now
        }
        try { locationManager.setTestProviderLocation(LocationManager.GPS_PROVIDER, loc) } catch (_: Exception) {}
        try {
            locationManager.setTestProviderLocation(LocationManager.NETWORK_PROVIDER,
                Location(loc).apply { provider = LocationManager.NETWORK_PROVIDER })
        } catch (_: Exception) {}
    }

    private fun updateCoords() {
        coords?.text = "Lat %.6f\nLon %.6f".format(lat, lon)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(loop)
        try { if (panel != null) wm.removeView(panel) } catch (_: Exception) {}
        panel = null
        try {
            for (provider in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                try { locationManager.setTestProviderEnabled(provider, false); locationManager.removeTestProvider(provider) } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        super.onDestroy()
    }
}

private class FloatingJoystick(context: Context, private val move: (Float, Float) -> Unit) : View(context) {
    private val base = Paint(3).apply { color = 0xFFDCE2ED.toInt() }
    private val ring = Paint(3).apply { color = 0xFF919EB4.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f }
    private val knob = Paint(3).apply { color = 0xFF2457D6.toInt() }
    private var kx = 0f
    private var ky = 0f

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val cx = width / 2f; val cy = height / 2f
        val r = minOf(width, height) * .34f
        c.drawCircle(cx, cy, r, base)
        c.drawCircle(cx, cy, r, ring)
        c.drawCircle(cx + kx, cy + ky, r * .28f, knob)
        val p = Paint(3).apply { color = 0xFF41506A.toInt(); textSize = 24f; textAlign = Paint.Align.CENTER }
        c.drawText("N", cx, cy - r - 8, p)
        c.drawText("S", cx, cy + r + 28, p)
        c.drawText("W", cx - r - 18, cy + 8, p)
        c.drawText("E", cx + r + 18, cy + 8, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cx = width / 2f; val cy = height / 2f
        val r = minOf(width, height) * .34f
        when (e.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                var x = e.x - cx; var y = e.y - cy
                val d = sqrt(x*x + y*y)
                if (d > r) { x = x / d * r; y = y / d * r }
                kx = x; ky = y
                move((x / r).coerceIn(-1f, 1f), (y / r).coerceIn(-1f, 1f))
                invalidate(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                kx = 0f; ky = 0f; move(0f, 0f); invalidate(); return true
            }
        }
        return true
    }
}
