package com.example.virtualjoystickgps

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 32, 28, 28)
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        val title = TextView(this).apply {
            text = "Virtual Joystick GPS V2"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(0xFF14213D.toInt())
        }
        val description = TextView(this).apply {
            text = "Floating joystick • mock GPS • speed control • starting coordinates"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 20)
        }
        val info = TextView(this).apply {
            text = "Setup: grant location permission, allow display over other apps, then choose this app under Developer options > Select mock location app."
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        }
        val overlayPermission = Button(this).apply {
            text = "1. Allow floating overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Overlay permission already granted.", Toast.LENGTH_SHORT).show()
            }
        }
        val locationPermission = Button(this).apply {
            text = "2. Grant location permission"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 23 &&
                    checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)
                } else Toast.makeText(this@MainActivity, "Location permission already granted.", Toast.LENGTH_SHORT).show()
            }
        }
        val start = Button(this).apply {
            text = "3. Start floating joystick"
            setOnClickListener {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this@MainActivity, "Grant location permission first.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Allow floating overlay first.", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    return@setOnClickListener
                }
                try {
                    startService(Intent(this@MainActivity, JoystickOverlayService::class.java).setAction(JoystickOverlayService.ACTION_START))
                    Toast.makeText(this@MainActivity, "Floating joystick started.", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Could not start overlay: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        val stop = Button(this).apply {
            text = "Stop floating joystick"
            setOnClickListener { stopService(Intent(this@MainActivity, JoystickOverlayService::class.java)) }
        }
        listOf(title, description, info, overlayPermission, locationPermission, start, stop).forEach {
            root.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        }
        setContentView(root)
    }
}
