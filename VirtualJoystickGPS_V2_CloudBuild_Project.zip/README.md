# Virtual Joystick GPS V2

Version 2 adds a floating overlay joystick that can remain visible while switching to another app, adjustable speed, reset coordinates, draggable header, and a foreground service.

## Build the APK
This environment does not include Android SDK/Gradle, so the APK cannot be compiled or device-tested here. To produce the APK:
1. Install Android Studio and JDK 17 on a computer.
2. Open this folder in Android Studio and allow Gradle sync.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Setup on Android
1. Install the APK.
2. Open it and grant location permission.
3. Tap "Allow floating overlay" and enable "Display over other apps".
4. Open Developer options > Select mock location app > choose Virtual Joystick GPS V2.
5. Tap "Start floating joystick".
6. Drag the dark header to reposition the overlay; use the joystick to move the simulated coordinates; use the speed slider to adjust speed; RESET returns to Manila coordinates; CLOSE removes the overlay.

## Limitations
- This is source code for a development/testing tool, not a compiled APK.
- Android vendor builds may restrict mock-location providers. Test on your device.
- Other apps may detect, reject, or ignore mock GPS.
- Starting coordinates are set to Manila (14.5995, 120.9842) in `JoystickOverlayService.kt`.


## Build without a computer (GitHub cloud build)
This project includes `.github/workflows/android.yml` for a cloud build. You need a GitHub account and use your phone browser:
1. Sign in at GitHub and create a new repository.
2. Upload the extracted project files/folders to the repository (make sure `.github/workflows/android.yml` is included).
3. Open the repository's **Actions** tab and select **Build Android APK**.
4. Tap **Run workflow** if it did not start automatically after upload.
5. Wait for the workflow to finish successfully.
6. Open the completed run, scroll to **Artifacts**, and download `VirtualJoystickGPS-V2-debug-apk`.
7. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Install it and allow installation from that source if Android asks.

The cloud workflow has been added but has not been run from this environment. It may reveal build errors that must be corrected before the APK is produced.
