# VirtualJoystickGPS V2 — Editable Coordinates

This Android project adds the following to the app's main screen:
- Editable latitude and longitude fields.
- A "USE MY CURRENT GPS LOCATION" button that requests a fresh location and fills the fields (when location providers are available).
- "APPLY COORDINATES & START JOYSTICK" to start the floating joystick at the entered coordinates.
- The overlay RESET button returns to the selected starting coordinates.

## Build
Use Android Gradle Plugin and Kotlin Android plugin as defined in the project Gradle files. The repository's cloud workflow should extract this ZIP into a project directory and run `gradle assembleDebug` there.

Mock GPS requires the user to explicitly select this app in Android Developer options > Select mock location app. App behavior can vary by Android version and device settings.
