package com.example.virtualjoystickgps

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var latitudeInput: EditText
    private lateinit var longitudeInput: EditText
    private lateinit var statusText: TextView
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingLocationListener: LocationListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFF5F7FB.toInt())
        }

        val title = TextView(this).apply {
            text = "Virtual Joystick GPS V2"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(0xFF14213D.toInt())
        }
        val description = TextView(this).apply {
            text = "Choose your starting location, then move it with the floating joystick."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 18)
        }

        val coordTitle = TextView(this).apply {
            text = "STARTING COORDINATES"
            textSize = 16f
            setTextColor(0xFF14213D.toInt())
            setPadding(0, 8, 0, 6)
        }

        latitudeInput = EditText(this).apply {
            hint = "Latitude (e.g. 14.5995)"
            singleLine = true
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText("14.599500")
        }
        longitudeInput = EditText(this).apply {
            hint = "Longitude (e.g. 120.9842)"
            singleLine = true
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText("120.984200")
        }

        val currentLocation = Button(this).apply {
            text = "USE MY CURRENT GPS LOCATION"
            setOnClickListener { useCurrentLocation() }
        }

        val applyStart = Button(this).apply {
            text = "APPLY COORDINATES & START JOYSTICK"
            setOnClickListener { startJoystickWithEnteredCoordinates() }
        }

        val note = TextView(this).apply {
            text = "Enter latitude (-90 to 90) and longitude (-180 to 180), or use your phone's current GPS location."
            textSize = 13f
            setTextColor(0xFF536078.toInt())
            setPadding(0, 4, 0, 12)
        }

        statusText = TextView(this).apply {
            text = "Starting location not applied yet."
            textSize = 13f
            setTextColor(0xFF536078.toInt())
            setPadding(0, 4, 0, 12)
        }

        val overlayPermission = Button(this).apply {
            text = "ALLOW FLOATING OVERLAY"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    Toast.makeText(this@MainActivity, "Overlay permission already granted.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val locationPermission = Button(this).apply {
            text = "GRANT LOCATION PERMISSION"
            setOnClickListener {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)
                } else {
                    Toast.makeText(this@MainActivity, "Location permission already granted.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val stop = Button(this).apply {
            text = "STOP FLOATING JOYSTICK"
            setOnClickListener {
                stopService(Intent(this@MainActivity, JoystickOverlayService::class.java))
                statusText.text = "Floating joystick stopped."
            }
        }

        listOf(
            title, description, coordTitle, latitudeInput, longitudeInput,
            currentLocation, applyStart, note, statusText, overlayPermission,
            locationPermission, stop
        ).forEach { view ->
            root.addView(view, LinearLayout.LayoutParams(-1, if (view is EditText) -2 else -2).apply {
                bottomMargin = 8
            })
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun startJoystickWithEnteredCoordinates() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Grant location permission first.", Toast.LENGTH_LONG).show()
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow floating overlay first.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }

        val lat = latitudeInput.text.toString().trim().toDoubleOrNull()
        val lon = longitudeInput.text.toString().trim().toDoubleOrNull()
        if (lat == null || lon == null || lat !in -90.0..90.0 || lon !in -180.0..180.0) {
            Toast.makeText(this, "Enter valid coordinates: latitude -90..90, longitude -180..180.", Toast.LENGTH_LONG).show()
            return
        }

        try {
            val serviceIntent = Intent(this, JoystickOverlayService::class.java).apply {
                action = JoystickOverlayService.ACTION_START
                putExtra(JoystickOverlayService.EXTRA_LATITUDE, lat)
                putExtra(JoystickOverlayService.EXTRA_LONGITUDE, lon)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
            statusText.text = "Starting location applied: %.6f, %.6f".format(lat, lon)
            Toast.makeText(this, "Starting coordinates applied.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            statusText.text = "Could not start joystick: ${e.message}"
            Toast.makeText(this, "Could not start joystick: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun useCurrentLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)
            Toast.makeText(this, "Allow location permission, then tap again.", Toast.LENGTH_LONG).show()
            return
        }

        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        val lastKnown = try {
            providers.mapNotNull { provider ->
                try { if (lm.isProviderEnabled(provider)) lm.getLastKnownLocation(provider) else null }
                catch (_: Exception) { null }
            }.maxByOrNull { it.time }
        } catch (_: Exception) { null }

        if (lastKnown != null && System.currentTimeMillis() - lastKnown.time < 10 * 60 * 1000L) {
            setCoordinateFields(lastKnown)
        }

        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                removePendingLocationUpdates(lm)
                setCoordinateFields(location)
            }
            @Deprecated("Deprecated in Android")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }

        pendingLocationListener = listener
        try {
            var requested = false
            for (provider in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                try {
                    if (lm.isProviderEnabled(provider)) {
                        lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
                        requested = true
                    }
                } catch (_: Exception) {}
            }
            if (!requested) {
                if (lastKnown == null) {
                    statusText.text = "No current GPS fix. Turn on Location and try outdoors."
                    Toast.makeText(this, "No current GPS fix. Turn on Location and try again.", Toast.LENGTH_LONG).show()
                }
                return
            }
            statusText.text = if (lastKnown != null) "Refreshing current GPS location…" else "Waiting for a GPS fix…"
            mainHandler.postDelayed({
                if (pendingLocationListener === listener) {
                    removePendingLocationUpdates(lm)
                    if (lastKnown == null) {
                        statusText.text = "Could not get a fresh location. Turn on Location and try outdoors."
                        Toast.makeText(this, "Could not get a fresh location. Try outdoors.", Toast.LENGTH_LONG).show()
                    }
                }
            }, 12000L)
        } catch (e: Exception) {
            statusText.text = "Location error: ${e.message}"
            Toast.makeText(this, "Location error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun setCoordinateFields(location: Location) {
        latitudeInput.setText("%.6f".format(location.latitude))
        longitudeInput.setText("%.6f".format(location.longitude))
        statusText.text = "Current location loaded. Tap APPLY COORDINATES & START JOYSTICK to use it."
    }

    private fun removePendingLocationUpdates(lm: LocationManager) {
        val listener = pendingLocationListener ?: return
        try { lm.removeUpdates(listener) } catch (_: Exception) {}
        pendingLocationListener = null
    }

    override fun onDestroy() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        removePendingLocationUpdates(lm)
        super.onDestroy()
    }
}
