package com.example.virtualjoystickgps

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var latitudeInput: EditText
    private lateinit var longitudeInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        val title = TextView(this).apply {
            text = "Virtual Joystick GPS V2"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(0xFF14213D.toInt())
        }
        val description = TextView(this).apply {
            text = "Set your starting location, edit coordinates, then start the floating joystick."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 18)
        }
        val overlayPermission = Button(this).apply {
            text = "1. Allow floating overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Overlay permission already granted.", Toast.LENGTH_SHORT).show()
            }
        }
        val locationPermission = Button(this).apply {
            text = "2. Grant location permission"
            setOnClickListener {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)
                } else Toast.makeText(this@MainActivity, "Location permission already granted.", Toast.LENGTH_SHORT).show()
            }
        }

        val coordinateTitle = TextView(this).apply {
            text = "Starting coordinates"
            textSize = 18f
            setTextColor(0xFF14213D.toInt())
            setPadding(0, 14, 0, 6)
        }
        latitudeInput = EditText(this).apply {
            hint = "Latitude (e.g. 14.599500)"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText("14.599500")
            contentDescription = "Latitude"
        }
        longitudeInput = EditText(this).apply {
            hint = "Longitude (e.g. 120.984200)"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText("120.984200")
            contentDescription = "Longitude"
        }
        val currentLocation = Button(this).apply {
            text = "USE MY CURRENT LOCATION"
            setOnClickListener { loadCurrentLocation() }
        }
        val start = Button(this).apply {
            text = "APPLY COORDINATES & START JOYSTICK"
            setOnClickListener { startJoystickWithCoordinates() }
        }
        val stop = Button(this).apply {
            text = "STOP FLOATING JOYSTICK"
            setOnClickListener { stopService(Intent(this@MainActivity, JoystickOverlayService::class.java)) }
        }

        listOf(title, description, overlayPermission, locationPermission, coordinateTitle,
            latitudeInput, longitudeInput, currentLocation, start, stop).forEach { view ->
            root.addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun loadCurrentLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Grant location permission first.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val candidates = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            var best: Location? = null
            for (provider in candidates) {
                val location = try { lm.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
                if (location != null && (best == null || location.time > best!!.time)) best = location
            }
            if (best == null) {
                Toast.makeText(this, "No recent location found. Turn on Location and try outdoors, or enter coordinates manually.", Toast.LENGTH_LONG).show()
                return
            }
            latitudeInput.setText("%.6f".format(java.util.Locale.US, best!!.latitude))
            longitudeInput.setText("%.6f".format(java.util.Locale.US, best!!.longitude))
            Toast.makeText(this, "Coordinates filled from the last known device location. Check them before applying.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not read location: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startJoystickWithCoordinates() {
        val latitude = latitudeInput.text.toString().trim().toDoubleOrNull()
        val longitude = longitudeInput.text.toString().trim().toDoubleOrNull()
        if (latitude == null || latitude !in -90.0..90.0) {
            latitudeInput.error = "Enter latitude from -90 to 90"
            return
        }
        if (longitude == null || longitude !in -180.0..180.0) {
            longitudeInput.error = "Enter longitude from -180 to 180"
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Grant location permission first.", Toast.LENGTH_LONG).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow floating overlay first.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        try {
            val intent = Intent(this, JoystickOverlayService::class.java)
                .setAction(JoystickOverlayService.ACTION_START)
                .putExtra(JoystickOverlayService.EXTRA_LATITUDE, latitude)
                .putExtra(JoystickOverlayService.EXTRA_LONGITUDE, longitude)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            Toast.makeText(this, "Starting coordinates applied: %.6f, %.6f".format(java.util.Locale.US, latitude, longitude), Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start joystick: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
